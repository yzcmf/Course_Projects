import md5
import binascii


result = ""
base_str = ""
# how many char digits we decide to search as a string length
metric = "\x27\x3d\x27"
def test(hash_input):
    m = md5.new()
    m.update(hash_input)
    hash_output = m.digest()
    # print hash_output
    if hash_output[0] == metric[0]:
        if hash_output[1] == metric[1]:
            if hash_output[2] == metric[2]:
                for i in range(3,16):
                    if hash_output[i] == '\x27':
                        return
                print "this is the answer: " + hash_input + "\n and this is the output: " + hash_output
                exit(0)
    return
def printAllKLengthRec(ls, prefix, n, k):
    if k == 0:
        test(prefix)
        print prefix
        return
    for i in range(n):
        newPrefix = prefix + ls[i]
        printAllKLengthRec(ls, newPrefix, n, k - 1)
    return

ls = ['a'] * 90
for i in range(90):
    ls[i] = chr(i + 37)

char_digit = 5
for l in range(char_digit):
    printAllKLengthRec(ls, "", 90, char_digit)



print "nothing left here ... :("

# y = "".join(alpha.encode('hex') for alpha in result)

# 37 - 126 decimal range of characters we will use

# ' \x27  " \x22   0-9 \x30-\x39  = \x3d

# print ('||1-- )=\x27\x7c\x7c\x31\x2d\x2d\x20
#('or1-- ) = \x27\x4f\x52\x31\x2d\x2d\x20
#('=')=\x273d27  addition: behind cannot contain a ' or "
