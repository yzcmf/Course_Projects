Fill in the code for the monad instance in `src/Lib.hs`.

Use `stack test` to check your work.
