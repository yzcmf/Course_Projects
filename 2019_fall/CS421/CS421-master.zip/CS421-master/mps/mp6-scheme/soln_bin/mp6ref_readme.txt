
MP6 reference binary

Please get the latest version of this from the pinned Piazza post about it!
I won't update this binary in Git any further. Also, I'm adding it to gitignore.

-Eric

