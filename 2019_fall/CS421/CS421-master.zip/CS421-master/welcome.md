Welcome to your CS 421 Repository!
==================================

You will (eventually) have several directories here.

  + mps --- Contains your machine problem code
  + activities --- Here is where you work on and turn in activities
  + grade-reports --- Grade reports here.  Do not edit anything in this directory!
