# CS425
MPs for the CS425 course at UIUC

These were all programmed in golang

The list of projects are available at: https://courses.engr.illinois.edu/cs425/fa2018/assignments.html


MP1 - Distributed Grep - https://courses.engr.illinois.edu/cs425/fa2018/MP1.CS425.FA18.pdf

MP2 - Distributed Group Membership - https://courses.engr.illinois.edu/cs425/fa2018/MP2.CS425.FA18.pdf

MP3 - Distributed File Systems - https://courses.engr.illinois.edu/cs425/fa2018/MP3.CS425.FA18.pdf

MP4 - Crane Streaming - https://courses.engr.illinois.edu/cs425/fa2018/MP4.CS425.FA18.pdf
